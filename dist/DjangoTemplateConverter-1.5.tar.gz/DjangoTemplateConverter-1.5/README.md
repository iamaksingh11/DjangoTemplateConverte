pip install DjangoTemplateConverter
python setup.py sdist
twine upload dist/*